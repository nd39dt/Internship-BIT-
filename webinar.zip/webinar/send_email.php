<?php

require 'C:/xampp/php/pear/PHPUnit/Autoload.php'; // Adjust the path as needed

use PHPMailer_master\src\PHPMailer;
use PHPMailer_master\src\Exception;

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $user_email = filter_var($_POST['email'], FILTER_SANITIZE_EMAIL);
    $subject = "Your Subject Here";
    $message = "This is a test email sent from PHP.";

    if (filter_var($user_email, FILTER_VALIDATE_EMAIL)) {
        $mail = new PHPMailer(true);
        try {
            //Server settings
            $mail->isSMTP();
            $mail->Host = 'smtp.gmail.com'; // Set the SMTP server to send through
            $mail->SMTPAuth = true; // Enable SMTP authentication
            $mail->Username = 'narayanthakkar399@gmail.com'; // SMTP username
            $mail->Password = 'omnarayan53'; // SMTP password
            $mail->SMTPSecure = 'tls'; // Enable TLS encryption, `ssl` also accepted
            $mail->Port = 587; // TCP port to connect to

            //Recipients
            $mail->setFrom('narayanthakkar399@gmail.com', 'Mailer');
            $mail->addAddress($user_email); // Add a recipient

            // Content
            $mail->isHTML(true); // Set email format to HTML
            $mail->Subject = $subject;
            $mail->Body = $message;

            $mail->send();
            echo "Email has been sent to $user_email";
        } catch (Exception $e) {
            echo "Message could not be sent. Mailer Error: {$mail->ErrorInfo}";
        }
    } else {
        echo "Invalid email address.";
    }
}
?>
