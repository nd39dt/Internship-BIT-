-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jul 11, 2024 at 12:19 PM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `webinar`
--

-- --------------------------------------------------------

--
-- Table structure for table `generatewebinar`
--

CREATE TABLE `generatewebinar` (
  `Webinar_id` bigint(20) NOT NULL,
  `Webinar_Title` varchar(100) NOT NULL,
  `Webinar_details` varchar(500) NOT NULL,
  `Guest_Name` varchar(100) NOT NULL,
  `Guest_Contact_Number` bigint(15) NOT NULL,
  `Guest_Email` varchar(50) NOT NULL,
  `Webinar_Date` date NOT NULL,
  `Webinar_Time` varchar(20) NOT NULL,
  `Webinar_Price` varchar(10) NOT NULL,
  `Webinar_Joining_Link` varchar(500) NOT NULL,
  `Webinar_Image` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `generatewebinar`
--

INSERT INTO `generatewebinar` (`Webinar_id`, `Webinar_Title`, `Webinar_details`, `Guest_Name`, `Guest_Contact_Number`, `Guest_Email`, `Webinar_Date`, `Webinar_Time`, `Webinar_Price`, `Webinar_Joining_Link`, `Webinar_Image`) VALUES
(1, 'php', 'Learn full php cource ', 'khushi', 8927839810, 'khushi@gmail.com', '2024-07-19', '20:00', '199', 'https://us05web.zoom.us/j/84712619694?pwd=qYDiycGD3ZNTRihSyYobxwDymg1Fle.1', 'assets/uploads/668fae64aeb4e.jpg'),
(2, 'php', 'Learn full php cource ', 'Amit Pavar', 9898907823, 'apermar@gmail.com', '2024-07-15', '15:00', '99', 'https://us05web.zoom.us/j/84712619694?pwd=qYDiycGD3ZNTRihSyYobxwDymg1Fle.1', 'assets/uploads/668fa51c25fa6.jpg'),
(3, 'AutoCad', 'Now you learn drafting by using AutoCAD ', 'Dhruvi Thakkar', 9999999988, 'dhruvi@12gmail.com', '2024-07-20', '20:00', '899', 'https://us05web.zoom.us/j/84712619694?pwd=qYDiycGD3ZNTRihSyYobxwDymg1Fle.1', 'assets/uploads/668fb1234fcaf.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `registration`
--

CREATE TABLE `registration` (
  `UserType` varchar(15) NOT NULL,
  `Rid` int(11) NOT NULL,
  `FName` varchar(50) NOT NULL,
  `LName` varchar(50) NOT NULL,
  `Gender` varchar(10) NOT NULL,
  `Address` varchar(100) NOT NULL,
  `State` varchar(50) NOT NULL,
  `Country` varchar(50) NOT NULL,
  `Pincode` int(10) NOT NULL,
  `CollegeName` varchar(100) NOT NULL,
  `Department` varchar(50) NOT NULL,
  `Sem` int(5) NOT NULL,
  `CountryCode` varchar(20) NOT NULL,
  `MobileNumber` bigint(20) NOT NULL,
  `Email` varchar(50) NOT NULL,
  `Password` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `registration`
--

INSERT INTO `registration` (`UserType`, `Rid`, `FName`, `LName`, `Gender`, `Address`, `State`, `Country`, `Pincode`, `CollegeName`, `Department`, `Sem`, `CountryCode`, `MobileNumber`, `Email`, `Password`) VALUES
('Admin', 1, 'Narayan', 'Thakkar', 'male', '41-Rampark,SoC, Manjalpur, Vadodara', 'Gujarat', 'India', 390011, 'SPEC', 'Computer Engineering', 7, '+91', 9409421602, 'narayan.dhaval@gmail.com', 'nd39@2003'),
('User', 2, 'Dhruvi', 'Thakkar', 'male', '41-Rampark,SoC, Manjalpur, Vadodara', 'Gujarat', 'India', 390011, 'SVIT', 'Architecture', 9, '+91', 942737, 'dhruvi@gmail.com', 'dt15@2001'),
('User', 3, 'Sanjana', 'Kharva', 'female', '41-Rampark,SoC, Manjalpur, Vadodara', 'Gujarat', 'India', 390001, 'MSU', 'civil', 8, '+91', 7898675645, 'sanju@gmail.com', 'sanju@123'),
('User', 4, 'Harshil', 'Kharva', 'male', '32-harinagr', 'Gujarat', 'India', 390001, 'MSU', 'mechanical engineering', 7, '+91', 8987657867, 'harshil@gmail.com', 'harshil@123'),
('User', 5, 'Vinay', 'Kharva', 'male', '32-harinagr', 'Gujarat', 'India', 390001, 'MSU', 'civil', 1, '+91', 8987657867, 'harshil@gmail.com', 'harshil@123'),
('User', 6, 'Shiv', 'Thakkar', 'male', '41-Rampark,SoC, Manjalpur, Vadodara', 'Gujarat', 'India', 390011, 'Parul', 'computer science', 7, '+91', 9878674567, 'shivu@gmail.com', 'shiv@123'),
('female', 9, 'chandu', 'patel', 'male', '54-panchasheel school', 'Gujarat', 'India', 390011, 'panchasheel', 'electronics Engineering', 4, '+91', 9898986767, 'chandu@2034gmail.com', 'chandu123');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `generatewebinar`
--
ALTER TABLE `generatewebinar`
  ADD PRIMARY KEY (`Webinar_id`);

--
-- Indexes for table `registration`
--
ALTER TABLE `registration`
  ADD PRIMARY KEY (`Rid`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `generatewebinar`
--
ALTER TABLE `generatewebinar`
  MODIFY `Webinar_id` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `registration`
--
ALTER TABLE `registration`
  MODIFY `Rid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
