<?php

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $zoomLink = $_POST['zoom_link'];

    // Validate the Zoom link
    if (filter_var($zoomLink, FILTER_VALIDATE_URL) && strpos($zoomLink, 'zoom.us') !== false) {
        header("Location: " . $zoomLink);
        exit;
    } else {
        $error = "Please enter a valid Zoom meeting link.";
    }
}

?>