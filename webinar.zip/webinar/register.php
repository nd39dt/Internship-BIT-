<?php
include 'connection.php';

// Prepare and bind
$stmt = $conn->prepare("INSERT INTO registration (UserType, FName, LName, Gender, Address, State, Country, Pincode, CollegeName, Sem, Department, CountryCode, MobileNumber, Email, Password) VALUES ( ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
$stmt->bind_param("sssssssssssssss",$usertype, $firstname, $lastname, $gender, $address, $state, $country, $pincode, $college_name, $semester, $department, $country_code, $mobile_number, $email, $password);

// Set parameters and execute
$usertype=$_POST['usertype'];
$firstname = $_POST['firstname'];
$lastname = $_POST['lastname'];
$gender = $_POST['gender'];
$address = $_POST['address'];
$state = $_POST['state'];
$country = $_POST['country'];
$pincode = $_POST['pincode'];
$college_name = $_POST['college_name'];
$semester = $_POST['semester'];
$department = $_POST['department'];
$country_code = $_POST['country_code'];
$mobile_number = $_POST['mobile_number'];
$email = $_POST['email'];
$password = $_POST['password'];


if ($stmt->execute()) {
    $message = "Record stored succesfully!!!";
    $redirect_url = "Login.html"; // Replace with your actual redirect URL
    echo "<script>";
    echo "alert('" . addslashes($message) . "');";
    echo "window.location.href = '" . addslashes($redirect_url) . "';";
    echo "</script>";
} else {
    echo "Error: " . $stmt->error;
}

$stmt->close();
$conn->close();
?>
