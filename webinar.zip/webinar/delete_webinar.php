<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <meta content="width=device-width, initial-scale=1.0" name="viewport">
  <meta content="" name="description">
  <meta content="" name="keywords">
  <title>Delete Webinars</title>
  <!-- Favicons -->
  <link href="assets/img/favicon.png" rel="icon">
  <link href="assets/img/apple-touch-icon.png" rel="apple-touch-icon">

  <!-- Fonts -->
  <link href="https://fonts.googleapis.com" rel="preconnect">
  <link href="https://fonts.gstatic.com" rel="preconnect" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=Open+Sans:ital,wght@0,300;0,400;0,500;0,600;0,700;0,800;1,300;1,400;1,500;1,600;1,700;1,800&family=Raleway:ital,wght@0,100;0,200;0,300;0,400;0,500;0,600;0,700;0,800;0,900;1,100;1,200;1,300;1,400;1,500;1,600;1,700;1,800;1,900&display=swap" rel="stylesheet">

  <!-- Vendor CSS Files -->
  <link href="assets/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
  <link href="assets/vendor/bootstrap-icons/bootstrap-icons.css" rel="stylesheet">
  <link href="assets/vendor/aos/aos.css" rel="stylesheet">
  <link href="assets/vendor/glightbox/css/glightbox.min.css" rel="stylesheet">
  <link href="assets/vendor/swiper/swiper-bundle.min.css" rel="stylesheet">

  <!-- Main CSS File -->
  <link href="assets/css/main.css" rel="stylesheet">
  <link href="assets/css/ud.css" rel="stylesheet">
  <script>
    function validateDate() {
        var input = document.getElementById('dateInput');
        var selectedDate = new Date(input.value);
        var today = new Date();

        // Set hours, minutes, seconds, and milliseconds of today's date to 0
        today.setHours(0, 0, 0, 0);

        // Compare selectedDate with today's date
        if (selectedDate < today) {
            alert('Please select a date same as today or upcoming date.');
            input.value = ''; // Clear the input field
        }
    }
</script>

  <!-- =======================================================
  * Template Name: Ninestars
  * Template URL: https://bootstrapmade.com/ninestars-free-bootstrap-3-theme-for-creative/
  * Updated: Jun 27 2024 with Bootstrap v5.3.3
  * Author: BootstrapMade.com
  * License: https://bootstrapmade.com/license/
  ======================================================== -->
</head>

<body class="index-page">

  <header id="header" class="header d-flex align-items-center sticky-top">
    <div class="container-fluid container-xl position-relative d-flex align-items-center">

      <a href="index.html" class="logo d-flex align-items-center me-auto">
        <img width="119" height="42" src="https://websitedemos.net/webinar-02/wp-content/uploads/sites/762/2021/01/webinar-landing-template-logo.svg" alt="Webinar" decoding="async">
      </a>
      <nav id="navmenu" class="navmenu">
        <ul>
            <li><a href="admin.html" class="active"><button style="color: blue; background-color: rgb(252, 252, 252); width: 120px; height: 40px; border-radius: 5px;"><b>Back</b></button></a></li> 
            <li><a href="logout.php" class="active"><button style="color: blue; background-color: rgb(252, 252, 252); width: 120px; height: 40px; border-radius: 5px;"><b>Sign Out</b></button></a></li>    
        </ul>
        <i class="mobile-nav-toggle d-xl-none bi bi-list"></i>
      </nav>
    </div>
  </header>

  <main class="main">
  <div class="con">
        <h2>Delete Webinars</h2>
        <?php
        // Assuming you have a database connection established
        include 'connection.php';
        // Fetch webinars from database

        $query = "SELECT * from  generatewebinar";
        $result = mysqli_query($conn, $query);

        if (mysqli_num_rows($result) > 0) {
            echo "<table>";
            echo "<tr>
                    <th>Webinar Id</th>
                    <th>Webinar Title</th>
                    <th>Webinar Description</th>
                    <th>Guest Name</th>
                    <th>Guest Mobile Number</th>
                    <th>Guest Email</th>
                    <th>Webinar Date</th>
                    <th>Webinar Start Time</th>
                    <th>Price</th>
                    <th>Webinar Link</th>
                    <th>Image</th>
                    <th>Actions</th>
                  </tr>";

            while($row = mysqli_fetch_assoc($result)) {
                echo "<tr>";
                echo "<td>" . $row['Webinar_id'] . "</td>";
                echo "<td>" . $row['Webinar_Title'] . "</td>";
                echo "<td>" . $row['Webinar_details'] . "</td>";
                echo "<td>" . $row['Guest_Name'] . "</td>";
                echo "<td>" . $row['Guest_Contact_Number'] . "</td>";
                echo "<td>" . $row['Guest_Email'] . "</td>";
                echo "<td>" . $row['Webinar_Date'] . "</td>";
                echo "<td>" . $row['Webinar_Time'] . "</td>";
                echo "<td>" . $row['Webinar_Price'] . "</td>";
                echo "<td>" . $row['Webinar_Joining_Link'] . "</td>";
                echo "<td>" . $row['Webinar_Image'] . "</td>";
                echo '<td>
                        <form action="webinar_delete.php" method="post" onsubmit="return confirm(\'Are you sure you want to delete this webinar?\');">
                            <input type="hidden" name="Webinar_id" value="' . $row['Webinar_id'] . '">
                            <input type="submit" value="Delete">
                        </form>
                      </td>';
                echo "</tr>";
            }
            echo "</table>";
        } else {
            echo "No webinars found";
        }

        mysqli_close($conn);
        ?>
    </div>
  </main>

  <!-- Scroll Top -->
  <a href="#" id="scroll-top" class="scroll-top d-flex align-items-center justify-content-center"><i class="bi bi-arrow-up-short"></i></a>

  <!-- Preloader -->
  <div id="preloader"></div>

  <!-- Vendor JS Files -->
  <script src="assets/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
  <script src="assets/vendor/php-email-form/validate.js"></script>
  <script src="assets/vendor/aos/aos.js"></script>
  <script src="assets/vendor/glightbox/js/glightbox.min.js"></script>
  <script src="assets/vendor/imagesloaded/imagesloaded.pkgd.min.js"></script>
  <script src="assets/vendor/isotope-layout/isotope.pkgd.min.js"></script>
  <script src="assets/vendor/swiper/swiper-bundle.min.js"></script>

  <!-- Main JS File -->
  <script src="assets/js/main.js"></script>

</body>

</html>