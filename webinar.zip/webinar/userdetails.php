<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <meta content="width=device-width, initial-scale=1.0" name="viewport">
  <meta content="" name="description">
  <meta content="" name="keywords">
  <title>User</title>
  <!-- Favicons -->
  <link href="assets/img/favicon.png" rel="icon">
  <link href="assets/img/apple-touch-icon.png" rel="apple-touch-icon">

  <!-- Fonts -->
  <link href="https://fonts.googleapis.com" rel="preconnect">
  <link href="https://fonts.gstatic.com" rel="preconnect" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=Open+Sans:ital,wght@0,300;0,400;0,500;0,600;0,700;0,800;1,300;1,400;1,500;1,600;1,700;1,800&family=Raleway:ital,wght@0,100;0,200;0,300;0,400;0,500;0,600;0,700;0,800;0,900;1,100;1,200;1,300;1,400;1,500;1,600;1,700;1,800;1,900&display=swap" rel="stylesheet">

  <!-- Vendor CSS Files -->
  <link href="assets/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
  <link href="assets/vendor/bootstrap-icons/bootstrap-icons.css" rel="stylesheet">
  <link href="assets/vendor/aos/aos.css" rel="stylesheet">
  <link href="assets/vendor/glightbox/css/glightbox.min.css" rel="stylesheet">
  <link href="assets/vendor/swiper/swiper-bundle.min.css" rel="stylesheet">

  <!-- Main CSS File -->
  <link href="assets/css/main.css" rel="stylesheet">
  <link href="reg.css" rel="stylesheet">
  <!-- =======================================================
  * Template Name: Ninestars
  * Template URL: https://bootstrapmade.com/ninestars-free-bootstrap-3-theme-for-creative/
  * Updated: Jun 27 2024 with Bootstrap v5.3.3
  * Author: BootstrapMade.com
  * License: https://bootstrapmade.com/license/
  ======================================================== -->
</head>

<body class="index-page">

  <header id="header" class="header d-flex align-items-center sticky-top">
    <div class="container-fluid container-xl position-relative d-flex align-items-center">

      <a href="index.html" class="logo d-flex align-items-center me-auto">
        <img width="119" height="42" src="https://websitedemos.net/webinar-02/wp-content/uploads/sites/762/2021/01/webinar-landing-template-logo.svg" alt="Webinar" decoding="async">
      </a>
      <nav id="navmenu" class="navmenu">
        <ul>
          <li><a href="user.html" class="active"><button style="color: blue; background-color: rgb(252, 252, 252); width: 120px; height: 40px; border-radius: 5px;"><b>Back</b></button></a></li> 
          <li><a href="logout.php" class="active"><button style="color: blue; background-color: rgb(252, 252, 252); width: 120px; height: 40px; border-radius: 5px;"><b>Sign Out</b></button></a></li>
        </ul>
        <i class="mobile-nav-toggle d-xl-none bi bi-list"></i>
      </nav>
    </div>
  </header>

  <main class="main">
  <div class="container">
    <h2>Update Webinar</h2>
    <?php
    // Assuming you have a database connection established
    include 'connection.php';
    // Fetch webinar details based on Webinar_id
    if ($_SERVER["REQUEST_METHOD"] == "POST") {
        $user_type = $_POST['user_type'];
        $Email = $_POST['Email'];
        $password = $_POST['password'];
    
        // Prepare and execute SQL statement
        $stmt = $conn->prepare("SELECT * FROM registration WHERE UserType = ? AND Email = ? AND Password = ?");
        $stmt->bind_param("sss", $user_type, $Email, $password);
        $stmt->execute();
        $result = $stmt->get_result();
        if ($result)
        {
            echo '<form action="webinar_update.php" method="post">
                    <input type="hidden" name="Rid" value="' . $row['Rid'] . '">
                    <label for="FName">First Name:</label><br>
                    <input type="text" id="FName" name="FName" value="' . $row['FName'] . '"><br><br>
                    <label for="LName">Last Name:</label><br>
                    <input type="text" id="LName" name="LName" value="' . $row['LName'] . '"><br><br>
                    <label for="Gender">Gender:</label><br>
                    <select id="Gender" name="Gender" value="' . $row['Gender'] . '">
                        <option value="male">Male</option>
                        <option value="female">Female</option>
                        <option value="other">Other</option>
                    </select><br><br>
                    <label for="Address">Address:</label><br>
                    <input type="text" id="Address" name="Address" value="' . $row['Address'] . '"><br><br>
            
                    <label for="State">State:</label><br>
                    <input type="text" id="State" name="State" value="' . $row['State'] . '"><br><br>
            
                    <label for="Country">Country:</label><br>
                    <select id="Country" name="Country" value="' . $row['Country'] . '">
                        <option value="Afghanistan">Afghanistan</option>
                        <option value="Albania">Albania</option>
                        <option value="Algeria">Algeria</option>
                        <option value="Andorra">Andorra</option>
                        <option value="Angola">Angola</option>
                        <option value="Antigua and Barbuda">Antigua and Barbuda</option>
                        <option value="Argentina">Argentina</option>
                        <option value="Armenia">Armenia</option>
                        <option value="Australia">Australia</option>
                        <option value="Austria">Austria</option>
                        <option value="Azerbaijan">Azerbaijan</option>
                        <option value="Bahamas">Bahamas</option>
                        <option value="Bahrain">Bahrain</option>
                        <option value="Bangladesh">Bangladesh</option>
                        <option value="Barbados">Barbados</option>
                        <option value="Belarus">Belarus</option>
                        <option value="Belgium">Belgium</option>
                        <option value="Belize">Belize</option>
                        <option value="Benin">Benin</option>
                        <option value="Bhutan">Bhutan</option>
                        <option value="Bolivia">Bolivia</option>
                        <option value="Bosnia and Herzegovina">Bosnia and Herzegovina</option>
                        <option value="Botswana">Botswana</option>
                        <option value="Brazil">Brazil</option>
                        <option value="Brunei">Brunei</option>
                        <option value="Bulgaria">Bulgaria</option>
                        <option value="Burkina Faso">Burkina Faso</option>
                        <option value="Burundi">Burundi</option>
                        <option value="Cabo Verde">Cabo Verde</option>
                        <option value="Cambodia">Cambodia</option>
                        <option value="Cameroon">Cameroon</option>
                        <option value="Canada">Canada</option>
                        <option value="Central African Republic">Central African Republic</option>
                        <option value="Chad">Chad</option>
                        <option value="Chile">Chile</option>
                        <option value="China">China</option>
                        <option value="Colombia">Colombia</option>
                        <option value="Comoros">Comoros</option>
                        <option value="Congo">Congo</option>
                        <option value="Costa Rica">Costa Rica</option>
                        <option value="Croatia">Croatia</option>
                        <option value="Cuba">Cuba</option>
                        <option value="Cyprus">Cyprus</option>
                        <option value="Czech Republic">Czech Republic</option>
                        <option value="Denmark">Denmark</option>
                        <option value="Djibouti">Djibouti</option>
                        <option value="Dominica">Dominica</option>
                        <option value="Dominican Republic">Dominican Republic</option>
                        <option value="Ecuador">Ecuador</option>
                        <option value="Egypt">Egypt</option>
                        <option value="El Salvador">El Salvador</option>
                        <option value="Equatorial Guinea">Equatorial Guinea</option>
                        <option value="Eritrea">Eritrea</option>
                        <option value="Estonia">Estonia</option>
                        <option value="Eswatini">Eswatini</option>
                        <option value="Ethiopia">Ethiopia</option>
                        <option value="Fiji">Fiji</option>
                        <option value="Finland">Finland</option>
                        <option value="France">France</option>
                        <option value="Gabon">Gabon</option>
                        <option value="Gambia">Gambia</option>
                        <option value="Georgia">Georgia</option>
                        <option value="Germany">Germany</option>
                        <option value="Ghana">Ghana</option>
                        <option value="Greece">Greece</option>
                        <option value="Grenada">Grenada</option>
                        <option value="Guatemala">Guatemala</option>
                        <option value="Guinea">Guinea</option>
                        <option value="Guinea-Bissau">Guinea-Bissau</option>
                        <option value="Guyana">Guyana</option>
                        <option value="Haiti">Haiti</option>
                        <option value="Honduras">Honduras</option>
                        <option value="Hungary">Hungary</option>
                        <option value="Iceland">Iceland</option>
                        <option value="India">India</option>
                        <option value="Indonesia">Indonesia</option>
                        <option value="Iran">Iran</option>
                        <option value="Iraq">Iraq</option>
                        <option value="Ireland">Ireland</option>
                        <option value="Israel">Israel</option>
                        <option value="Italy">Italy</option>
                        <option value="Jamaica">Jamaica</option>
                        <option value="Japan">Japan</option>
                        <option value="Jordan">Jordan</option>
                        <option value="Kazakhstan">Kazakhstan</option>
                        <option value="Kenya">Kenya</option>
                        <option value="Kiribati">Kiribati</option>
                        <option value="Kuwait">Kuwait</option>
                        <option value="Kyrgyzstan">Kyrgyzstan</option>
                        <option value="Laos">Laos</option>
                        <option value="Latvia">Latvia</option>
                        <option value="Lebanon">Lebanon</option>
                        <option value="Lesotho">Lesotho</option>
                        <option value="Liberia">Liberia</option>
                        <option value="Libya">Libya</option>
                        <option value="Liechtenstein">Liechtenstein</option>
                        <option value="Lithuania">Lithuania</option>
                        <option value="Luxembourg">Luxembourg</option>
                        <option value="Madagascar">Madagascar</option>
                        <option value="Malawi">Malawi</option>
                        <option value="Malaysia">Malaysia</option>
                        <option value="Maldives">Maldives</option>
                        <option value="Mali">Mali</option>
                        <option value="Malta">Malta</option>
                        <option value="Marshall Islands">Marshall Islands</option>
                        <option value="Mauritania">Mauritania</option>
                        <option value="Mauritius">Mauritius</option>
                        <option value="Mexico">Mexico</option>
                        <option value="Micronesia">Micronesia</option>
                        <option value="Moldova">Moldova</option>
                        <option value="Monaco">Monaco</option>
                        <option value="Mongolia">Mongolia</option>
                        <option value="Montenegro">Montenegro</option>
                        <option value="Morocco">Morocco</option>
                        <option value="Mozambique">Mozambique</option>
                        <option value="Myanmar">Myanmar</option>
                        <option value="Namibia">Namibia</option>
                        <option value="Nauru">Nauru</option>
                        <option value="Nepal">Nepal</option>
                        <option value="Netherlands">Netherlands</option>
                        <option value="New Zealand">New Zealand</option>
                        <option value="Nicaragua">Nicaragua</option>
                        <option value="Niger">Niger</option>
                        <option value="Nigeria">Nigeria</option>
                        <option value="North Korea">North Korea</option>
                        <option value="North Macedonia">North Macedonia</option>
                        <option value="Norway">Norway</option>
                        <option value="Oman">Oman</option>
                        <option value="Pakistan">Pakistan</option>
                        <option value="Palau">Palau</option>
                        <option value="Palestine">Palestine</option>
                        <option value="Panama">Panama</option>
                        <option value="Papua New Guinea">Papua New Guinea</option>
                        <option value="Paraguay">Paraguay</option>
                        <option value="Peru">Peru</option>
                        <option value="Philippines">Philippines</option>
                        <option value="Poland">Poland</option>
                        <option value="Portugal">Portugal</option>
                        <option value="Qatar">Qatar</option>
                        <option value="Romania">Romania</option>
                        <option value="Russia">Russia</option>
                        <option value="Rwanda">Rwanda</option>
                        <option value="Saint Kitts and Nevis">Saint Kitts and Nevis</option>
                        <option value="Saint Lucia">Saint Lucia</option>
                        <option value="Saint Vincent and the Grenadines">Saint Vincent and the Grenadines</option>
                        <option value="Samoa">Samoa</option>
                        <option value="San Marino">San Marino</option>
                        <option value="Saudi Arabia">Saudi Arabia</option>
                        <option value="Senegal">Senegal</option>
                        <option value="Serbia">Serbia</option>
                        <option value="Seychelles">Seychelles</option>
                        <option value="Sierra Leone">Sierra Leone</option>
                        <option value="Singapore">Singapore</option>
                        <option value="Slovakia">Slovakia</option>
                        <option value="Slovenia">Slovenia</option>
                        <option value="Solomon Islands">Solomon Islands</option>
                        <option value="Somalia">Somalia</option>
                        <option value="South Africa">South Africa</option>
                        <option value="South Korea">South Korea</option>
                        <option value="South Sudan">South Sudan</option>
                        <option value="Spain">Spain</option>
                        <option value="Sri Lanka">Sri Lanka</option>
                        <option value="Sudan">Sudan</option>
                        <option value="Suriname">Suriname</option>
                        <option value="Sweden">Sweden</option>
                        <option value="Switzerland">Switzerland</option>
                        <option value="Syria">Syria</option>
                        <option value="Taiwan">Taiwan</option>
                        <option value="Tajikistan">Tajikistan</option>
                        <option value="Tanzania">Tanzania</option>
                        <option value="Thailand">Thailand</option>
                        <option value="Timor-Leste">Timor-Leste</option>
                        <option value="Togo">Togo</option>
                        <option value="Tonga">Tonga</option>
                        <option value="Trinidad and Tobago">Trinidad and Tobago</option>
                        <option value="Tunisia">Tunisia</option>
                        <option value="Turkey">Turkey</option>
                        <option value="Turkmenistan">Turkmenistan</option>
                        <option value="Tuvalu">Tuvalu</option>
                        <option value="Uganda">Uganda</option>
                        <option value="Ukraine">Ukraine</option>
                        <option value="United Arab Emirates">United Arab Emirates</option>
                        <option value="United Kingdom">United Kingdom</option>
                        <option value="United States">United States</option>
                        <option value="Uruguay">Uruguay</option>
                        <option value="Uzbekistan">Uzbekistan</option>
                        <option value="Vanuatu">Vanuatu</option>
                        <option value="Venezuela">Venezuela</option>
                        <option value="Vietnam">Vietnam</option>
                        <option value="Yemen">Yemen</option>
                        <option value="Zambia">Zambia</option>
                        <option value="Zimbabwe">Zimbabwe</option>
                    </select><br><br>
            
                    <label for="Pincode">Pincode:</label><br>
                    <input type="text" id="Pincode" name="Pincode" value="' . $row['Pincode'] . '" onblur="fetchLocationData()"><br><br>
            
                    <label for="CollegeName">College Name:</label><br>
                    <input type="text" id="CollegeName" name="CollegeName" value="' . $row['CollegeName'] . '"><br><br>
            
                    <label for="Sem">Semester:</label><br>
                    <select id="Sem" name="Sem" value="' . $row['Sem'] . '">
                        <option value="1">1st</option>
                        <option value="2">2nd</option>
                        <option value="3">3rd</option>
                        <option value="4">4th</option>
                        <option value="5">5th</option>
                        <option value="6">6th</option>
                        <option value="7">7th</option>
                        <option value="8">8th</option>
                        <option value="9">9th</option>
                        <option value="10">10th</option>
                    </select><br><br>
                    
                    <label for="Department">Department:</label><br>
                    <select id="Department" name="Department" value="' . $row['Department'] . '">
                        <option value="civil">Civil Engineering</option>
                        <option value="computer Engineering">Computer Engineering</option>
                        <option value="computer science">Computer Science & Engineering</option>
                        <option value="electrical engineering">Electrical Engineering</option>
                        <option value="electronics Engineering">Electronics and communication engineering</option>
                        <option value="IT Engineering">IT Engineering</option>
                        <option value="mechanical engineering">Mechanical Engineering</option>
                        <option values="other">Other</option>
                    </select><br><br>
            
                    <label for="MobileNumber">Mobile Number:</label><br>
                    <select id="CountryCode" name="CountryCode" value="' . $row['CountryCode'] . '">
                        <option value="+93">+93 Afghanistan</option>
                        <option value="+355">+355 Albania</option>
                        <option value="+213">+213 Algeria</option>
                        <option value="+1 684">+1 684 American Samoa</option>
                        <option value="+376">+376 Andorra</option>
                        <option value="+244">+244 Angola</option>
                        <option value="+1 264">+1 264 Anguilla</option>
                        <option value="+672">+672 Antarctica</option>
                        <option value="+1 268">+1 268 Antigua and Barbuda</option>
                        <option value="+54">+54 Argentina</option>
                        <option value="+374">+374 Armenia</option>
                        <option value="+297">+297 Aruba</option>
                        <option value="+61">+61 Australia</option>
                        <option value="+43">+43 Austria</option>
                        <option value="+994">+994 Azerbaijan</option>
                        <option value="+1 242">+1 242 Bahamas</option>
                        <option value="+973">+973 Bahrain</option>
                        <option value="+880">+880 Bangladesh</option>
                        <option value="+1 246">+1 246 Barbados</option>
                        <option value="+375">+375 Belarus</option>
                        <option value="+32">+32 Belgium</option>
                        <option value="+501">+501 Belize</option>
                        <option value="+229">+229 Benin</option>
                        <option value="+1 441">+1 441 Bermuda</option>
                        <option value="+975">+975 Bhutan</option>
                        <option value="+591">+591 Bolivia</option>
                        <option value="+387">+387 Bosnia and Herzegovina</option>
                        <option value="+267">+267 Botswana</option>
                        <option value="+55">+55 Brazil</option>
                        <option value="+246">+246 British Indian Ocean Territory</option>
                        <option value="+673">+673 Brunei</option>
                        <option value="+359">+359 Bulgaria</option>
                        <option value="+226">+226 Burkina Faso</option>
                        <option value="+257">+257 Burundi</option>
                        <option value="+855">+855 Cambodia</option>
                        <option value="+237">+237 Cameroon</option>
                        <option value="+1">+1 Canada</option>
                        <option value="+238">+238 Cape Verde</option>
                        <option value="+ 345">+ 345 Cayman Islands</option>
                        <option value="+236">+236 Central African Republic</option>
                        <option value="+235">+235 Chad</option>
                        <option value="+56">+56 Chile</option>
                        <option value="+86">+86 China</option>
                        <option value="+61">+61 Christmas Island</option>
                        <option value="+61">+61 Cocos (Keeling) Islands</option>
                        <option value="+57">+57 Colombia</option>
                        <option value="+269">+269 Comoros</option>
                        <option value="+242">+242 Congo</option>
                        <option value="+243">+243 Congo, Democratic Republic of the</option>
                        <option value="+682">+682 Cook Islands</option>
                        <option value="+506">+506 Costa Rica</option>
                        <option value="+225">+225 Cote d Ivoire</option>
                        <option value="+385">+385 Croatia</option>
                        <option value="+53">+53 Cuba</option>
                        <option value="+357">+357 Cyprus</option>
                        <option value="+420">+420 Czech Republic</option>
                        <option value="+45">+45 Denmark</option>
                        <option value="+253">+253 Djibouti</option>
                        <option value="+1 767">+1 767 Dominica</option>
                        <option value="+1 809">+1 809 Dominican Republic</option>
                        <option value="+670">+670 East Timor</option>
                        <option value="+593">+593 Ecuador</option>
                        <option value="+20">+20 Egypt</option>
                        <option value="+503">+503 El Salvador</option>
                        <option value="+240">+240 Equatorial Guinea</option>
                        <option value="+291">+291 Eritrea</option>
                        <option value="+372">+372 Estonia</option>
                        <option value="+251">+251 Ethiopia</option>
                        <option value="+500">+500 Falkland Islands (Malvinas)</option>
                        <option value="+298">+298 Faroe Islands</option>
                        <option value="+679">+679 Fiji</option>
                        <option value="+358">+358 Finland</option>
                        <option value="+33">+33 France</option>
                        <option value="+594">+594 French Guiana</option>
                        <option value="+689">+689 French Polynesia</option>
                        <option value="+241">+241 Gabon</option>
                        <option value="+220">+220 Gambia</option>
                        <option value="+995">+995 Georgia</option>
                        <option value="+49">+49 Germany</option>
                        <option value="+233">+233 Ghana</option>
                        <option value="+350">+350 Gibraltar</option>
                        <option value="+30">+30 Greece</option>
                        <option value="+299">+299 Greenland</option>
                        <option value="+1 473">+1 473 Grenada</option>
                        <option value="+590">+590 Guadeloupe</option>
                        <option value="+1 671">+1 671 Guam</option>
                        <option value="+502">+502 Guatemala</option>
                        <option value="+224">+224 Guinea</option>
                        <option value="+245">+245 Guinea-Bissau</option>
                        <option value="+592">+592 Guyana</option>
                        <option value="+509">+509 Haiti</option>
                        <option value="+504">+504 Honduras</option>
                        <option value="+852">+852 Hong Kong</option>
                        <option value="+36">+36 Hungary</option>
                        <option value="+354">+354 Iceland</option>
                        <option value="+91" selected>+91 India</option>
                        <option value="+62">+62 Indonesia</option>
                        <option value="+98">+98 Iran</option>
                        <option value="+964">+964 Iraq</option>
                        <option value="+353">+353 Ireland</option>
                        <option value="+972">+972 Israel</option>
                        <option value="+39">+39 Italy</option>
                        <option value="+1 876">+1 876 Jamaica</option>
                        <option value="+81">+81 Japan</option>
                        <option value="+962">+962 Jordan</option>
                        <option value="+7">+7 Kazakhstan</option>
                        <option value="+254">+254 Kenya</option>
                        <option value="+686">+686 Kiribati</option>
                        <option value="+850">+850 Korea, Democratic Peoples Republic of</option>
                        <option value="+82">+82 Korea, Republic of</option>
                        <option value="+965">+965 Kuwait</option>
                        <option value="+996">+996 Kyrgyzstan</option>
                        <option value="+856">+856 Laos</option>
                        <option value="+371">+371 Latvia</option>
                        <option value="+961">+961 Lebanon</option>
                        <option value="+266">+266 Lesotho</option>
                        <option value="+231">+231 Liberia</option>
                        <option value="+218">+218 Libya</option>
                        <option value="+423">+423 Liechtenstein</option>
                        <option value="+370">+370 Lithuania</option>
                        <option value="+352">+352 Luxembourg</option>
                        <option value="+853">+853 Macau</option>
                        <option value="+389">+389 Macedonia</option>
                        <option value="+261">+261 Madagascar</option>
                        <option value="+265">+265 Malawi</option>
                        <option value="+60">+60 Malaysia</option>
                        <option value="+960">+960 Maldives</option>
                        <option value="+223">+223 Mali</option>
                        <option value="+356">+356 Malta</option>
                        <option value="+692">+692 Marshall Islands</option>
                        <option value="+596">+596 Martinique</option>
                        <option value="+222">+222 Mauritania</option>
                        <option value="+230">+230 Mauritius</option>
                        <option value="+262">+262 Mayotte</option>
                        <option value="+52">+52 Mexico</option>
                        <option value="+691">+691 Micronesia, Federated States of</option>
                        <option value="+373">+373 Moldova, Republic of</option>
                        <option value="+377">+377 Monaco</option>
                        <option value="+976">+976 Mongolia</option>
                        <option value="+382">+382 Montenegro</option>
                        <option value="+1 664">+1 664 Montserrat</option>
                        <option value="+212">+212 Morocco</option>
                        <option value="+258">+258 Mozambique</option>
                        <option value="+95">+95 Myanmar</option>
                        <option value="+264">+264 Namibia</option>
                        <option value="+674">+674 Nauru</option>
                        <option value="+977">+977 Nepal</option>
                        <option value="+31">+31 Netherlands</option>
                        <option value="+599">+599 Netherlands Antilles</option>
                        <option value="+687">+687 New Caledonia</option>
                        <option value="+64">+64 New Zealand</option>
                        <option value="+505">+505 Nicaragua</option>
                        <option value="+227">+227 Niger</option>
                        <option value="+234">+234 Nigeria</option>
                        <option value="+683">+683 Niue</option>
                        <option value="+672">+672 Norfolk Island</option>
                        <option value="+1 670">+1 670 Northern Mariana Islands</option>
                        <option value="+47">+47 Norway</option>
                        <option value="+968">+968 Oman</option>
                        <option value="+92">+92 Pakistan</option>
                        <option value="+680">+680 Palau</option>
                        <option value="+970">+970 Palestine</option>
                        <option value="+507">+507 Panama</option>
                        <option value="+675">+675 Papua New Guinea</option>
                        <option value="+595">+595 Paraguay</option>
                        <option value="+51">+51 Peru</option>
                        <option value="+63">+63 Philippines</option>
                        <option value="+64">+64 Pitcairn</option>
                        <option value="+48">+48 Poland</option>
                        <option value="+351">+351 Portugal</option>
                        <option value="+1 787">+1 787 Puerto Rico</option>
                        <option value="+974">+974 Qatar</option>
                        <option value="+262">+262 Reunion</option>
                        <option value="+40">+40 Romania</option>
                        <option value="+7">+7 Russian Federation</option>
                        <option value="+250">+250 Rwanda</option>
                        <option value="+290">+290 Saint Helena</option>
                        <option value="+1 869">+1 869 Saint Kitts and Nevis</option>
                        <option value="+1 758">+1 758 Saint Lucia</option>
                        <option value="+508">+508 Saint Pierre and Miquelon</option>
                        <option value="+1 784">+1 784 Saint Vincent and the Grenadines</option>
                        <option value="+685">+685 Samoa</option>
                        <option value="+378">+378 San Marino</option>
                        <option value="+239">+239 Sao Tome and Principe</option>
                        <option value="+966">+966 Saudi Arabia</option>
                        <option value="+221">+221 Senegal</option>
                        <option value="+381">+381 Serbia</option>
                        <option value="+248">+248 Seychelles</option>
                        <option value="+232">+232 Sierra Leone</option>
                        <option value="+65">+65 Singapore</option>
                        <option value="+421">+421 Slovakia</option>
                        <option value="+386">+386 Slovenia</option>
                        <option value="+677">+677 Solomon Islands</option>
                        <option value="+252">+252 Somalia</option>
                        <option value="+27">+27 South Africa</option>
                        <option value="+500">+500 South Georgia and the South Sandwich Islands</option>
                        <option value="+34">+34 Spain</option>
                        <option value="+94">+94 Sri Lanka</option>
                        <option value="+249">+249 Sudan</option>
                        <option value="+597">+597 Suriname</option>
                        <option value="+268">+268 Swaziland</option>
                        <option value="+46">+46 Sweden</option>
                        <option value="+41">+41 Switzerland</option>
                        <option value="+963">+963 Syrian Arab Republic</option>
                        <option value="+886">+886 Taiwan</option>
                        <option value="+992">+992 Tajikistan</option>
                        <option value="+255">+255 Tanzania, United Republic of</option>
                        <option value="+66">+66 Thailand</option>
                        <option value="+670">+670 Timor-Leste</option>
                        <option value="+228">+228 Togo</option>
                        <option value="+690">+690 Tokelau</option>
                        <option value="+676">+676 Tonga</option>
                        <option value="+1 868">+1 868 Trinidad and Tobago</option>
                        <option value="+216">+216 Tunisia</option>
                        <option value="+90">+90 Turkey</option>
                        <option value="+993">+993 Turkmenistan</option>
                        <option value="+688">+688 Tuvalu</option>
                        <option value="+256">+256 Uganda</option>
                        <option value="+380">+380 Ukraine</option>
                        <option value="+971">+971 United Arab Emirates</option>
                        <option value="+44">+44 United Kingdom</option>
                        <option value="+1">+1 United States</option>
                        <option value="+598">+598 Uruguay</option>
                        <option value="+998">+998 Uzbekistan</option>
                        <option value="+678">+678 Vanuatu</option>
                        <option value="+58">+58 Venezuela</option>
                        <option value="+84">+84 Vietnam</option>
                        <option value="+681">+681 Wallis and Futuna</option>
                        <option value="+967">+967 Yemen</option>
                        <option value="+260">+260 Zambia</option>
                        <option value="+263">+263 Zimbabwe</option>
                    </select>
                    <input type="text" id="MobileNumber" name="MobileNumber" value="' . $row['MobileNumber'] . '"><br><br>
            
                    <label for="	Email">Email:</label><br>
                    <input type="text" id="	Email" name="Email" value="' . $row['Email'] . '"><br><br>
            
                    <label for="Password">Password:</label><br>
                    <input type="text" id="Password" name="Password" value="' . $row['Password'] . '"><br><br>

                    <input type="submit" value="Update">
                  </form>';
        } else {
            echo "No webinar found with the provided ID.";
        }
        $stmt->close();
        $conn->close();
    } else {
        echo "Invalid request.";
    }
    ?>
</div>
  </main>

  <!-- Scroll Top -->
  <a href="#" id="scroll-top" class="scroll-top d-flex align-items-center justify-content-center"><i class="bi bi-arrow-up-short"></i></a>

  <!-- Preloader -->
  <div id="preloader"></div>

  <!-- Vendor JS Files -->
  <script src="assets/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
  <script src="assets/vendor/php-email-form/validate.js"></script>
  <script src="assets/vendor/aos/aos.js"></script>
  <script src="assets/vendor/glightbox/js/glightbox.min.js"></script>
  <script src="assets/vendor/imagesloaded/imagesloaded.pkgd.min.js"></script>
  <script src="assets/vendor/isotope-layout/isotope.pkgd.min.js"></script>
  <script src="assets/vendor/swiper/swiper-bundle.min.js"></script>

  <!-- Main JS File -->
  <script src="assets/js/main.js"></script>

</body>

</html>
