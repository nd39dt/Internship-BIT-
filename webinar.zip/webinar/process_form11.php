<?php
include 'connection.php';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $webinarData = [
        'Webinar_id' => $_POST['Webinar_id'],
        'webinartitle' => $_POST['webinartitle'],
        'webinardetails' => $_POST['webinardetails'],
        'Gname' => $_POST['Gname'],
        'GuestMNo' => $_POST['GuestMNo'],
        'GEmail' => $_POST['GEmail'],
        'WDate' => $_POST['WDate'],
        'WTime' => $_POST['WTime'],
        'WPrice' => $_POST['WPrice'],
        'WLink' => $_POST['WLink']
    ];

    // Create connection
  

    // Check connection
    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }

    $sql = "INSERT INTO generatewebinar (Webinar_id,Webinar_Title, Webinar_details, Guest_Name, Guest_Contact_Number, Guest_Email, Webinar_Date, Webinar_Time, Webinar_Price, Webinar_Joining_Link)
    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";

    $stmt = $conn->prepare($sql);
    $stmt->bind_param(
        "ssssssssss",
        $Webinar_id['Webinar_id'],
        $webinarData['webinartitle'],
        $webinarData['webinardetails'],
        $webinarData['Gname'],
        $webinarData['GuestMNo'],
        $webinarData['GEmail'],
        $webinarData['WDate'],
        $webinarData['WTime'],
        $webinarData['WPrice'],
        $webinarData['WLink']
    );

    if ($stmt->execute()) {
        echo "New record created successfully";
    } else {
        echo "Error: " . $sql . "<br>" . $conn->error;
    }

    $stmt->close();
    $conn->close();

    // Redirect back to admin page or show success message
    header('Location: admin.php');
    exit();
} else {
    echo "Invalid request.";
}
?>









