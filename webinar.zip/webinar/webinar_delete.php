<?php
// Assuming you have a database connection established
include 'connection.php';
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['Webinar_id'])) {
    $Webinar_id = $_POST['Webinar_id'];
    
    // Perform SQL DELETE operation
    // Example:
    $sql = "DELETE FROM generatewebinar WHERE Webinar_id = $Webinar_id";

    if (mysqli_query($conn, $sql)) {
        $message = "Webinar deleted successfully!!";
        $redirect_url = "delete_webinar.php"; // Replace with your actual redirect URL
        echo "<script>";
        echo "alert('" . addslashes($message) . "');";
        echo "window.location.href = '" . addslashes($redirect_url) . "';";
        echo "</script>";
    } else {
        echo "Error deleting webinar: " . mysqli_error($conn);
    }
    
    mysqli_close($conn);
}
?>
