<?php

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $to = $_POST['to']; // For example: '1234567890'
    $message = $_POST['message'];
    $instanceId = 'your_instance_id';
    $token = 'your_api_token';

    $data = [
        'phone' => $to, // recipient phone number without '+' or 'whatsapp:'
        'body' => $message,
    ];

    $url = 'https://api.ultramsg.com/'.$instanceId.'/messages/chat';

    $options = [
        'http' => [
            'header' => "Content-type: application/x-www-form-urlencoded\r\nAuthorization: Bearer ".$token."\r\n",
            'method' => 'POST',
            'content' => http_build_query($data),
        ],
    ];

    $context = stream_context_create($options);
    $result = file_get_contents($url, false, $context);

    if ($result === FALSE) {
        echo "Error: Unable to send message.";
    } else {
        echo "Message sent successfully!";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Send WhatsApp Message</title>
</head>
<body>
    <form method="POST" action="">
        <label for="to">Phone Number (without country code):</label><br>
        <input type="text" id="to" name="to" placeholder="1234567890"><br><br>
        
        <label for="message">Message:</label><br>
        <textarea id="message" name="message" placeholder="Type your message here"></textarea><br><br>

        <input type="submit" value="Send Message">
    </form>
</body>
</html>
