 <script>
        function validateForm() {
            let isValid = true;

            // Clear previous errors
            document.querySelectorAll('.error').forEach(e => e.innerHTML = '');

            // Validate User Type
            const userType = document.forms["regForm"]["user_type"].value;
            if (userType == "") {
                document.getElementById("userTypeError").innerHTML = "User type is required";
                isValid = false;
            }

            // Validate Enrollment
            const enrollment = document.forms["regForm"]["enrollment"].value;
            if (enrollment == "") {
                document.getElementById("enrollmentError").innerHTML = "Enrollment is required";
                isValid = false;
            }

            // Validate Department
            const department = document.forms["regForm"]["department"].value;
            if (department == "") {
                document.getElementById("departmentError").innerHTML = "Department is required";
                isValid = false;
            }

            // Validate Name
            const name = document.forms["regForm"]["name"].value;
            if (name == "") {
                document.getElementById("nameError").innerHTML = "Name is required";
                isValid = false;
            }

            // Validate Phone number
            const phone = document.forms["regForm"]["phone"].value;
            if (phone == "") {
                document.getElementById("phoneError").innerHTML = "Phone number is required";
                isValid = false;
            } else if (!/^\d{10}$/.test(phone)) {
                document.getElementById("phoneError").innerHTML = "Phone number must be 10 digits";
                isValid = false;
            }

            // Validate Address
            const address = document.forms["regForm"]["address"].value;
            if (address == "") {
                document.getElementById("addressError").innerHTML = "Address is required";
                isValid = false;
            }

            // Validate Semester
            const semester = document.forms["regForm"]["semester"].value;
            if (semester == "") {
                document.getElementById("semesterError").innerHTML = "Semester is required";
                isValid = false;
            }

            // Validate Email
            const email = document.forms["regForm"]["email"].value;
            if (email == "") {
                document.getElementById("emailError").innerHTML = "Email is required";
                isValid = false;
            } else if (!/^\S+@\S+\.\S+$/.test(email)) {
                document.getElementById("emailError").innerHTML = "Invalid email format";
                isValid = false;
            }

            // Validate Password
            const password = document.forms["regForm"]["password"].value;
            if (password == "") {
                document.getElementById("passwordError").innerHTML = "Password is required";
                isValid = false;
            } else if (password.length < 6) {
                document.getElementById("passwordError").innerHTML = "Password must be at least 6 characters";
                isValid = false;
            }

            return isValid;
        }
    </script>