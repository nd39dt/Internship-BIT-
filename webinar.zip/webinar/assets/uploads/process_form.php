<?php
include 'connection.php';

// Set parameters
$Webinar_id = $_POST['Webinar_id'];
$webinartitle = $_POST['webinartitle'];
$webinardetails = $_POST['webinardetails'];
$Gname = $_POST['Gname'];
$GuestMNo = $_POST['GuestMNo'];
$GEmail = $_POST['GEmail'];
$WDate = $_POST['WDate'];
$WTime = $_POST['WTime'];
$WPrice = $_POST['WPrice'];
$WLink = $_POST['WLink'];

// Handle image upload
$imageFileType = strtolower(pathinfo($_FILES["imageUpload"]["name"], PATHINFO_EXTENSION));
$target_dir = "uploads/";
$target_file = $target_dir . uniqid() . "." . $imageFileType;
$uploadOk = 1;

// Check if image file is a actual image or fake image
$check = getimagesize($_FILES["imageUpload"]["tmp_name"]);
if($check !== false) {
    $uploadOk = 1;
} else {
    echo "File is not an image.";
    $uploadOk = 0;
}

// Check if file already exists
if (file_exists($target_file)) {
    echo "Sorry, file already exists.";
    $uploadOk = 0;
}

// Check file size
if ($_FILES["imageUpload"]["size"] > 500000) { // 500KB max size
    echo "Sorry, your file is too large.";
    $uploadOk = 0;
}

// Allow certain file formats
if($imageFileType != "jpg" && $imageFileType != "png" && $imageFileType != "jpeg" && $imageFileType != "gif" ) {
    echo "Sorry, only JPG, JPEG, PNG & GIF files are allowed.";
    $uploadOk = 0;
}

// Check if $uploadOk is set to 0 by an error
if ($uploadOk == 0) {
    echo "Sorry, your file was not uploaded.";
// if everything is ok, try to upload file
} else {
    if (move_uploaded_file($_FILES["imageUpload"]["tmp_name"], $target_file)) {
        // File is uploaded successfully, include the path in the database

        // Prepare and bind
        $stmt = $conn->prepare("INSERT INTO generatewebinar (Webinar_id, Webinar_Title, Webinar_details, Guest_Name, Guest_Contact_Number, Guest_Email, Webinar_Date, Webinar_Time, Webinar_Price, Webinar_Joining_Link, Webinar_Image) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
        $stmt->bind_param("sssssssssss", $Webinar_id, $webinartitle, $webinardetails, $Gname, $GuestMNo, $GEmail, $WDate, $WTime, $WPrice, $WLink, $target_file);

        if ($stmt->execute()) {
            $message = "Webinar created successfully!!!";
            $redirect_url = "create_webinar.html"; // Replace with your actual redirect URL
            echo "<script>";
            echo "alert('" . addslashes($message) . "');";
            echo "window.location.href = '" . addslashes($redirect_url) . "';";
            echo "</script>";
        } else {
            echo "Error: " . $stmt->error;
        }

        $stmt->close();
    } else {
        echo "Sorry, there was an error uploading your file.";
    }
}

$conn->close();
?>
