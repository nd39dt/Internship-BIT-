<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta content="width=device-width, initial-scale=1.0" name="viewport">
  <meta content="" name="description">
  <meta content="" name="keywords">

  <link href="assets/img/favicon.png" rel="icon">
  <link href="assets/img/apple-touch-icon.png" rel="apple-touch-icon">
  <link href="https://fonts.googleapis.com/css2?family=Open+Sans:wght@400;600&family=Raleway:wght@500;700&display=swap" rel="stylesheet">
  <link href="assets/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
  <link href="assets/vendor/bootstrap-icons/bootstrap-icons.css" rel="stylesheet">
  <link href="assets/vendor/aos/aos.css" rel="stylesheet">
  <link href="assets/vendor/glightbox/css/glightbox.min.css" rel="stylesheet">
  <link href="assets/vendor/swiper/swiper-bundle.min.css" rel="stylesheet">
  <link href="assets/css/main.css" rel="stylesheet">
  
  <title>Webinar Submissions</title>
  <style>
    .container {
      border: 1px solid #ccc;
      padding: 15px;
      margin: 15px;
    }
  </style>
</head>
<body class="index-page">
  <header id="header" class="header d-flex align-items-center sticky-top">
    <div class="container-fluid container-xl position-relative d-flex align-items-center">
      <a href="index.html" class="logo d-flex align-items-center me-auto">
        <img width="119" height="42" src="https://websitedemos.net/webinar-02/wp-content/uploads/sites/762/2021/01/webinar-landing-template-logo.svg" alt="Webinar" decoding="async">
      </a>
      <nav id="navmenu" class="navmenu">
        <ul>
          <li><a href="admin.php" class="active"><button style="color: blue; background-color: rgb(252, 252, 252); width: 120px; height: 40px; border-radius: 5px;"><b>Back</b></button></a></li> 
          <li><a href="logout.php" class="active"><button style="color: blue; background-color: rgb(252, 252, 252); width: 120px; height: 40px; border-radius: 5px;"><b>Sign Out</b></button></a></li>
        </ul>
        <i class="mobile-nav-toggle d-xl-none bi bi-list"></i>
      </nav>
    </div>
  </header>

  <main class="main">
    <div class="container">
        <h2>Webinar Submissions</h2>
        <?php
        include 'connection.php';

        // Check connection
        if ($conn->connect_error) {
            die("Connection failed: " . $conn->connect_error);
        }

        $sql = "SELECT * FROM generatewebinar";
        $result = $conn->query($sql);

        if ($result->num_rows > 0) {
            while ($row = $result->fetch_assoc()) {
                echo '<div class="container">';
                echo '<h3>' . htmlspecialchars($row['Webinar_Title']) . '</h3>';
                echo '<p><strong>Description:</strong> ' . htmlspecialchars($row['Webinar_details']) . '</p>';
                echo '<p><strong>Guest Name:</strong> ' . htmlspecialchars($row['Guest_Name']) . '</p>';
                echo '<p><strong>Guest Mobile Number:</strong> ' . htmlspecialchars($row['Guest_Contact_Number']) . '</p>';
                echo '<p><strong>Guest Email:</strong> ' . htmlspecialchars($row['Guest_Email']) . '</p>';
                echo '<p><strong>Webinar Date:</strong> ' . htmlspecialchars($row['Webinar_Date']) . '</p>';
                echo '<p><strong>Webinar Start Time:</strong> ' . htmlspecialchars($row['Webinar_Time']) . '</p>';
                echo '<p><strong>Price:</strong> ' . htmlspecialchars($row['Webinar_Price']) . '</p>';
                echo '<p><strong>Webinar Link:</strong> <a href="' . htmlspecialchars($row['Webinar_Joining_Link']) . '" target="_blank">Join Webinar</a></p>';
                echo '</div>';
            }
        } else {
            echo '<p>No webinars found.</p>';
        }

        $conn->close();
        ?>
    </div>
  </main>

  <a href="#" id="scroll-top" class="scroll-top d-flex align-items-center justify-content-center"><i class="bi bi-arrow-up-short"></i></a>
  <div id="preloader"></div>

  <script src="assets/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
  <script src="assets/vendor/php-email-form/validate.js"></script>
  <script src="assets/vendor/aos/aos.js"></script>
  <script src="assets/vendor/glightbox/js/glightbox.min.js"></script>
  <script src="assets/vendor/imagesloaded/imagesloaded.pkgd.min.js"></script>
  <script src="assets/vendor/isotope-layout/isotope.pkgd.min.js"></script>
  <script src="assets/vendor/swiper/swiper-bundle.min.js"></script>
  <script src="assets/js/main.js"></script>
</body>
</html>
