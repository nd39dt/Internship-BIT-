<?php

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $zoomLink = $_POST['zoom_link'];

    // Validate the Zoom link
    if (filter_var($zoomLink, FILTER_VALIDATE_URL) && strpos($zoomLink, 'zoom.us') !== false) {
        header("Location: " . $zoomLink);
        exit;
    } else {
        $error = "Please enter a valid Zoom meeting link.";
    }
}

?>


<script src="assets/vendor/php-email-form/validate.js"></script>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Join Zoom Meeting</title>
</head>
<body>
    <h2>Join Zoom Meeting</h2>
    <form method="POST" action="">
        <label for="zoom_link">Zoom Meeting Link:</label><br>
        <input type="text" id="zoom_link" name="zoom_link" placeholder="https://zoom.us/j/your_meeting_id"><br><br>
        <?php if (!empty($error)): ?>
            <p style="color: red;"><?php echo $error; ?></p>
        <?php endif; ?>
        <input type="submit" value="Join Meeting">
    </form>
</body>
</html>
