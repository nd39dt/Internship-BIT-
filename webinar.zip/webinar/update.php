<?php
// Start session if not already started
session_start();

// Check if user is logged in
if (!isset($_SESSION['loggedin']) || $_SESSION['loggedin'] !== true) {
    // Redirect user to login page if not logged in
    header("Location: login.php");
    exit();
}

// Here you can fetch user data from your database using $_SESSION['username']
$loggedInUsername = $_SESSION['username'];

// Example: Fetch user data from database
// Replace with your database query to fetch user data based on $loggedInUsername
// $db = new PDO('mysql:host=localhost;dbname=mydatabase', 'username', 'password');
// $stmt = $db->prepare("SELECT * FROM users WHERE username = :username");
// $stmt->execute(array(':username' => $loggedInUsername));
// $user = $stmt->fetch(PDO::FETCH_ASSOC);

// Example data (replace with actual data retrieval)
$user = [
    'username' => $loggedInUsername,
    'email' => 'user@example.com',
    // Add more fields as needed
];
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>User Update</title>
</head>
<body>
    <h1>Welcome, <?php echo $user['username']; ?>!</h1>
    
    <form action="update_process.php" method="post">
        <label for="email">Email:</label>
        <input type="email" id="email" name="email" value="<?php echo $user['email']; ?>" required>
        <br><br>
        <input type="submit" value="Update">
    </form>
</body>
</html>
 