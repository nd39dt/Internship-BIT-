<?php
// Assuming you have a database connection established
include 'connection.php';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $webinar_id = $_POST['Webinar_id'];
    $webinar_title = $_POST['Webinar_Title'];
    $webinar_details = $_POST['Webinar_details'];
    $guest_name = $_POST['Guest_Name'];
    $guest_contact_number = $_POST['Guest_Contact_Number'];
    $guest_email = $_POST['Guest_Email'];
    $webinar_date = $_POST['Webinar_Date'];
    $webinar_time = $_POST['Webinar_Time'];
    $webinar_price = $_POST['Webinar_Price'];
    $webinar_joining_link = $_POST['Webinar_Joining_Link'];

    $query = "UPDATE generatewebinar SET 
              Webinar_Title = '$webinar_title', 
              Webinar_details = '$webinar_details', 
              Guest_Name = '$guest_name', 
              Guest_Contact_Number = '$guest_contact_number', 
              Guest_Email = '$guest_email', 
              Webinar_Date = '$webinar_date', 
              Webinar_Time = '$webinar_time', 
              Webinar_Price = '$webinar_price', 
              Webinar_Joining_Link = '$webinar_joining_link' 
              WHERE Webinar_id = '$webinar_id'";

    if (mysqli_query($conn, $query)) {

        $message = "Webinar updated successfully!!";
        $redirect_url = "Display_webinar.php"; // Replace with your actual redirect URL
        echo "<script>";
        echo "alert('" . addslashes($message) . "');";
        echo "window.location.href = '" . addslashes($redirect_url) . "';";
        echo "</script>";
    } else {
        echo "Error updating webinar: " . mysqli_error($conn);
        
    }

    mysqli_close($conn);
} else {
    echo "Invalid request.";
}
?>
