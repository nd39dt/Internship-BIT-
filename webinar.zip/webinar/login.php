<?php
session_start();
include 'connection.php';
if ($_SERVER["REQUEST_METHOD"] == "POST") {
   
    // Fetch user inputs
    $user_type = $_POST['user_type'];
    $Email = $_POST['Email'];
    $password = $_POST['password'];

    // Prepare and execute SQL statement
    $stmt = $conn->prepare("SELECT * FROM registration WHERE UserType = ? AND Email = ? AND Password = ?");
    $stmt->bind_param("sss", $user_type, $Email, $password);
    $stmt->execute();

    // Get result
    $result = $stmt->get_result();

    // Check if user is authenticated
    if ($result->num_rows == 1) {
        // User authenticated, set user type in session
        $_SESSION['user_type'] = $user_type;

        // Redirect based on user type
        if ($user_type == "Admin") {
            $_SESSION['Email'] =$Email;
            $_SESSION['loggedin'] = true;
            header("Location: admin.html"); // Redirect to faculty dashboard
            exit();
        } elseif ($user_type == "User") {
            $_SESSION['Email'] =$Email;
            $_SESSION['loggedin'] = true;
            header("Location: display.php"); // Redirect to student dashboard
            exit();
        }
    } else {
        // Invalid credentials, redirect back to login page with error message
        $message = "Invalid credentials. Please try again.";
        $redirect_url = "Login.html"; // Replace with your actual redirect URL
        echo "<script>";
        echo "alert('" . addslashes($message) . "');";
        echo "window.location.href = '" . addslashes($redirect_url) . "';";
        echo "</script>";        
    }

    // Close connection
    $stmt->close();
    $conn->close();
}
?>
