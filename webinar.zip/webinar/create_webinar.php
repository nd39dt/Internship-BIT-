<?php
include 'connection.php';

// Prepare and bind
$stmt = $conn->prepare("INSERT INTO generatewebinar (Webinar_id,Webinar_Title, Webinar_details, Guest_Name, Guest_Contact_Number, Guest_Email, Webinar_Date, Webinar_Time, Webinar_Price, Webinar_Joining_Link) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
$stmt->bind_param("ssssssssss", $webinar_id, $webinartitle, $webinardetails, $Gname, $GuestMNo, $GEmail, $WDate, $WTime, $WPrice, $WLink);

// Set parameters and execute
$webinar_id=$_POST['webinar_id'];
$webinartitle=$_POST['webinartitle'];
$webinardetails=$_POST['webinardetails'];
$Gname=$_POST['Gname'];
$GuestMNo=$_POST['GuestMNo'];
$GEmail=$_POST['GEmail'];
$WDate=$_POST['WDate'];
$WTime=$_POST['WTime'];
$WPrice=$_POST['WPrice'];
$WLink=$_POST['WLink'];

if ($stmt->execute()) {

    $message = "Webinar created successfully!!!";
    $redirect_url = "create_webinar.html"; // Replace with your actual redirect URL
    echo "<script>";
    echo "alert('" . addslashes($message) . "');";
    echo "window.location.href = '" . addslashes($redirect_url) . "';";
    echo "</script>";
} else {
    echo "Error: " . $stmt->error;
}

$stmt->close();
$conn->close();
?>
