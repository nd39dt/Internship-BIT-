<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <meta content="width=device-width, initial-scale=1.0" name="viewport">
  <meta content="" name="description">
  <meta content="" name="keywords">
  <title>Update Webinar</title>
  <!-- Favicons -->
  <link href="assets/img/favicon.png" rel="icon">
  <link href="assets/img/apple-touch-icon.png" rel="apple-touch-icon">

  <!-- Fonts -->
  <link href="https://fonts.googleapis.com" rel="preconnect">
  <link href="https://fonts.gstatic.com" rel="preconnect" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=Open+Sans:ital,wght@0,300;0,400;0,500;0,600;0,700;0,800;1,300;1,400;1,500;1,600;1,700;1,800&family=Raleway:ital,wght@0,100;0,200;0,300;0,400;0,500;0,600;0,700;0,800;0,900;1,100;1,200;1,300;1,400;1,500;1,600;1,700;1,800;1,900&display=swap" rel="stylesheet">

  <!-- Vendor CSS Files -->
  <link href="assets/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
  <link href="assets/vendor/bootstrap-icons/bootstrap-icons.css" rel="stylesheet">
  <link href="assets/vendor/aos/aos.css" rel="stylesheet">
  <link href="assets/vendor/glightbox/css/glightbox.min.css" rel="stylesheet">
  <link href="assets/vendor/swiper/swiper-bundle.min.css" rel="stylesheet">

  <!-- Main CSS File -->
  <link href="assets/css/main.css" rel="stylesheet">
  <link href="reg.css" rel="stylesheet">
  <script>
    function validateDate() {
        var input = document.getElementById('dateInput');
        var selectedDate = new Date(input.value);
        var today = new Date();

        // Set hours, minutes, seconds, and milliseconds of today's date to 0
        today.setHours(0, 0, 0, 0);

        // Compare selectedDate with today's date
        if (selectedDate < today) {
            alert('Please select a date same as today or upcoming date.');
            input.value = ''; // Clear the input field
        }
    }
</script>

  <!-- =======================================================
  * Template Name: Ninestars
  * Template URL: https://bootstrapmade.com/ninestars-free-bootstrap-3-theme-for-creative/
  * Updated: Jun 27 2024 with Bootstrap v5.3.3
  * Author: BootstrapMade.com
  * License: https://bootstrapmade.com/license/
  ======================================================== -->
</head>

<body class="index-page">

  <header id="header" class="header d-flex align-items-center sticky-top">
    <div class="container-fluid container-xl position-relative d-flex align-items-center">

      <a href="index.html" class="logo d-flex align-items-center me-auto">
        <img width="119" height="42" src="https://websitedemos.net/webinar-02/wp-content/uploads/sites/762/2021/01/webinar-landing-template-logo.svg" alt="Webinar" decoding="async">
      </a>
      <nav id="navmenu" class="navmenu">
        <ul>
          <li><a href="Display_webinar.php" class="active"><button style="color: blue; background-color: rgb(252, 252, 252); width: 120px; height: 40px; border-radius: 5px;"><b>Back</b></button></a></li> 
          <li><a href="logout.php" class="active"><button style="color: blue; background-color: rgb(252, 252, 252); width: 120px; height: 40px; border-radius: 5px;"><b>Sign Out</b></button></a></li>
        </ul>
        <i class="mobile-nav-toggle d-xl-none bi bi-list"></i>
      </nav>
    </div>
  </header>

  <main class="main">
  <div class="container">
    <h2>Update Webinar</h2>
    <?php
    // Assuming you have a database connection established
    include 'connection.php';

    // Fetch webinar details based on Webinar_id
    if (isset($_POST['Webinar_id'])) {
        $webinar_id = $_POST['Webinar_id'];
        $query = "SELECT * FROM generatewebinar WHERE Webinar_id = '$webinar_id'";
        $result = mysqli_query($conn, $query);

        if ($row = mysqli_fetch_assoc($result)) {
            echo '<form action="webinar_update.php" method="post" enctype="multipart/form-data">
                    <input type="hidden" name="Webinar_id" value="' . $row['Webinar_id'] . '">
                    <label for="Webinar_Title">Webinar Title:</label><br>
                    <input type="text" id="Webinar_Title" name="Webinar_Title" value="' . $row['Webinar_Title'] . '"><br><br>
                    <label for="Webinar_details">Webinar Description:</label><br>
                    <textarea id="Webinar_details" name="Webinar_details">' . $row['Webinar_details'] . '</textarea><br><br>
                    <label for="Guest_Name">Guest Name:</label><br>
                    <input type="text" id="Guest_Name" name="Guest_Name" value="' . $row['Guest_Name'] . '"><br><br>
                    <label for="Guest_Contact_Number">Guest Mobile Number:</label><br>
                    <input type="text" id="Guest_Contact_Number" name="Guest_Contact_Number" value="' . $row['Guest_Contact_Number'] . '"><br><br>
                    <label for="Guest_Email">Guest Email:</label><br>
                    <input type="email" id="Guest_Email" name="Guest_Email" value="' . $row['Guest_Email'] . '"><br><br>
                    <label for="Webinar_Date">Webinar Date:</label><br>
                    <input type="date" id="Webinar_Date" name="Webinar_Date" value="' . $row['Webinar_Date'] . '"><br><br>
                    <label for="Webinar_Time">Webinar Start Time:</label><br>
                    <input type="time" id="Webinar_Time" name="Webinar_Time" value="' . $row['Webinar_Time'] . '"><br><br>
                    <label for="Webinar_Price">Price:</label><br>
                    <input type="text" id="Webinar_Price" name="Webinar_Price" value="' . $row['Webinar_Price'] . '"><br><br>
                    <label for="Webinar_Joining_Link">Webinar Link:</label><br>
                    <input type="text" id="Webinar_Joining_Link" name="Webinar_Joining_Link" value="' . $row['Webinar_Joining_Link'] . '"><br><br>
                    <label for="Webinar_Image">Update Image:</label><br>
                    <input type="file" id="Webinar_Image" name="Webinar_Image" accept="image/*" value="' . $row['Webinar_Image'] . '"><br><br>
                    <input type="submit" value="Update">
                  </form>';
        } else {
            echo "No webinar found with the provided ID.";
        }

        mysqli_close($conn);
    } else {
        echo "Invalid request.";
    }
    ?>
</div>
  </main>

  <!-- Scroll Top -->
  <a href="#" id="scroll-top" class="scroll-top d-flex align-items-center justify-content-center"><i class="bi bi-arrow-up-short"></i></a>

  <!-- Preloader -->
  <div id="preloader"></div>

  <!-- Vendor JS Files -->
  <script src="assets/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
  <script src="assets/vendor/php-email-form/validate.js"></script>
  <script src="assets/vendor/aos/aos.js"></script>
  <script src="assets/vendor/glightbox/js/glightbox.min.js"></script>
  <script src="assets/vendor/imagesloaded/imagesloaded.pkgd.min.js"></script>
  <script src="assets/vendor/isotope-layout/isotope.pkgd.min.js"></script>
  <script src="assets/vendor/swiper/swiper-bundle.min.js"></script>

  <!-- Main JS File -->
  <script src="assets/js/main.js"></script>

</body>

</html>
