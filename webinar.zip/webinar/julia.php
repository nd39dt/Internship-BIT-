<?php
include 'connection.php';
require 'C:\xampp\htdocs\webinar\PHPMailer_master\src\PHPMailer.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {

    $email = $_POST['email'];
    $password = $_POST['password'];
    $subject = "Test Email";
    $message = "This is a test email sent from a PHP script.";
    $headers = "From: narayanthakkar399@gmail.com";

    // Prepare and execute SQL statement
    $stmt = $conn->prepare("SELECT * FROM registration WHERE Email = ? AND Password = ?");
    $stmt->bind_param("ss", $email, $password);
    $stmt->execute();

    // Get result
    $result = $stmt->get_result();

    // Check if user is authenticated
    if ($result->num_rows == 1) {
        // User authenticated, set user type in session
        echo "done";
            if (mail($email, $subject, $message, $headers)) {
                echo "Email successfully sent to $email";
            } else {
                echo "Email sending failed...";
            }
        
    } else {
        // Invalid credentials, redirect back to login page with error message
        echo "Invalid credentials. Please try again.";
        header("Location: Julia.html");
        exit();
    }

    // Close connection
    $stmt->close();
    $conn->close();
}
?>

